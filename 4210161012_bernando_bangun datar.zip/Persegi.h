#include <iostream>
#include "BangunDatar.h"
using namespace std;

class persegi : public bangunDatar{
	public:
		double lebar;
		double panjang;
		double hitungLuas();
		double hitungKeliling();
};
