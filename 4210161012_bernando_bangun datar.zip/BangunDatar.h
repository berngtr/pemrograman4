#include <iostream>
using namespace std;

class bangunDatar{
	public:
		double keliling;
		double luas;
		virtual double hitungKeliling();
		virtual double hitungLuas();
};
