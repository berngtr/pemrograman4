#include <iostream>
#include "BangunDatar.h"
using namespace std;

class segitiga : public bangunDatar{
	public:
		double tinggi;
		double alas;
		double hitungLuas();
		double hitungKeliling();
};
