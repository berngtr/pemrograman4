#include <iostream>
#include "BangunDatar.h"
using namespace std;

class lingkaran : public bangunDatar{
	public:
		double radius;
		double hitungLuas();
		double hitungKeliling();
	
};
