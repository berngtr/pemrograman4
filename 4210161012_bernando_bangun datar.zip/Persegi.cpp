#include <iostream>
#include "Persegi.h"
using namespace std;

double persegi :: hitungLuas(){
	return panjang*lebar;
};

double persegi :: hitungKeliling(){
	return (panjang+lebar)*2;
};
