#include<iostream>
#include "Segitiga.h"
using namespace std;

double segitiga :: hitungLuas(){
	return alas*tinggi/2;
};
